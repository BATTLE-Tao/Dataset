The data are generated from MK01–MK10 and la01–la40.

EM01–10 correspond to MK01–MK10 with 10 workers (except MK06 and MK10, which have 20 workers due to having 15 machines).

EM011–30 correspond to la01–la20 with 10 workers. EM01–EM30 are referred to as small-scale datasets because they involve 10 workers.

EM031–50 correspond to la21–la40 with 20 workers. EM31–EM50 are referred to as large-scale datasets because they involve 20 workers.
